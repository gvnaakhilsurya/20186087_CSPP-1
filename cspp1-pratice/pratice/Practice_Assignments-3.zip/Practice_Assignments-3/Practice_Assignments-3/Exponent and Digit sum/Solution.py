# Write a function with 2 parameters number, exponent; calculate exponent of
# given number,then compute digit sum of the result.  number = 2 and exponent
# = 10. Result is : 1024. and sum of those digits is : 7

def calculate_digit_exponent_sum(number, exponent):
	'''
	Write a python program to calculate exponent of a given number and compute the digit 
	sum of the result.
	Note: Don’t use any in-build function in calculating exponent or power.
	'''
	pass



def main():
	number = int(input())
	exponent = int(input())
	print(calculate_digit_exponent_sum(number, exponent))

main()