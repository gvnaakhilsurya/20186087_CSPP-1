a = 'akhilsurya'
b = ''
for i,j in enumerate(a):
	if i % 4 == 0:
		b = b + j
print(b)

	# b = b + i * j

      