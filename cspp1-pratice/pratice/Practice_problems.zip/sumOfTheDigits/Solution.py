def sum_of_digits(x):
	'''
	integer parameter x.
	return the sum of all the digits of given number
	'''
	pass

def main():
	x = int(input())
	print(sum_of_digits(x))

main()