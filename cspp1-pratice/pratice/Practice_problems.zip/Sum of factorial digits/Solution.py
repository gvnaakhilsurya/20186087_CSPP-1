def fact(n):
	'''
	Use this function fact(n), which takes n as integer and returns n!
	'''
	pass

def sum_of_fact(n):
	'''
	argument : n, integer type.
	return type: integer, which is the sum of factorial of each digit in n.
	example : 123 = 1! + 2! + 3! = 1 + 2 + 6 = 9
	Your task is to write code here and use fact(n) to find factorial for each digit.
	'''
	pass

def main():
	print(sum_of_fact(int(input())))

main()