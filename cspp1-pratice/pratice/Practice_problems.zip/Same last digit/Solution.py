def same_last_digit(x, y):
	'''
	return True, if last digit in both the numbers are equal
	otherwise return False
	'''
	pass

def main():
	x = int(input())
	y = int(input())
	print(same_last_digit(x,y))

main()