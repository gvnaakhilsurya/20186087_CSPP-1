def same_first_digit(x, y):
	'''
	return True, if first digit in both the numbers are equal
	otherwise return False
	'''
	pass

def main():
	x = int(input())
	y = int(input())
	print(same_first_digit(x,y))

main()